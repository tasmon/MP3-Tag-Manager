#!/bin/bash
# Build MP3 Tag Manager for macOS

set -e
cd "$(dirname "$0")"

echo "========================================"
echo " Building MP3 Tag Manager for macOS"
echo "========================================"
echo

if ! command -v python3 &> /dev/null; then
    echo "[ERROR] python3 not found"
    exit 1
fi

echo "Installing dependencies..."
pip3 install -r requirements.txt pyinstaller --quiet

echo
echo "Building standalone .app..."
pyinstaller --noconfirm --onefile --windowed \
    --name "MP3_Tag_Manager" \
    --clean \
    mp3_tag_manager.py

echo
echo "========================================"
echo " BUILD SUCCESSFUL!"
echo "========================================"
echo
echo "Executable created at:"
echo "  dist/MP3_Tag_Manager"
echo
echo "On macOS you can also create a .app bundle with:"
echo "  pyinstaller --noconfirm --windowed --name MP3_Tag_Manager mp3_tag_manager.py"
echo "  (then look in dist/MP3_Tag_Manager.app)"
