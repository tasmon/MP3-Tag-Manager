@echo off
title Build MP3 Tag Manager for Windows
cd /d "%~dp0"

echo ========================================
echo  Building MP3 Tag Manager for Windows
echo ========================================
echo.

where python >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Download from https://www.python.org
    pause
    exit /b 1
)

echo Installing dependencies...
pip install -r requirements.txt pyinstaller --quiet

echo.
echo Building standalone .exe (this may take 1-2 minutes)...
pyinstaller --noconfirm --onefile --windowed ^
    --name "MP3_Tag_Manager" ^
    --clean ^
    mp3_tag_manager.py

if %errorlevel% equ 0 (
    echo.
    echo ========================================
    echo  BUILD SUCCESSFUL!
    echo ========================================
    echo.
    echo Executable created at:
    echo   dist\MP3_Tag_Manager.exe
    echo.
    echo You can copy this .exe anywhere and run it.
    echo No Python installation is needed on the target PC.
) else (
    echo.
    echo [ERROR] Build failed. Check the output above.
)

echo.
pause
